# Di dalam file: nama_app/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('my-activity/', views.my_activity_view, name='my-activity'),
]
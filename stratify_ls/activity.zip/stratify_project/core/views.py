from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Post, Comment, Like

@login_required
def my_activity_view(request):
    
    current_user = request.user

    # Ambil setiap jenis aktivitas secara terpisah dan urutkan
    user_posts = Post.objects.filter(author=current_user).order_by('-created_at')
    user_comments = Comment.objects.filter(author=current_user).order_by('-created_at')
    user_likes = Like.objects.filter(user=current_user).order_by('-created_at')

    # Kirim data ke template dalam konteks yang terpisah
    context = {
        'posts': user_posts,
        'comments': user_comments,
        'likes': user_likes,
    }

    return render(request, 'core/my_activity.html', context)